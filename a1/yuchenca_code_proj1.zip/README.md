# Assignment 1 Colorizing the Prokudin-Gorskii Photo Collection
Joshua Cao | yuchenca@andrew.cmu.edu

files for website:
-index.html
-css/
-media/
-js/

files for code:
-main.ipynb (jupyter notebook)
-main.py (python)
-output/