$(function() {

$('#text-gt').click(function() {
  $('#navigation a[href="#gt"]').tab('show');
});

$('#text-code').click(function() {
  $('#navigation a[href="#code"]').tab('show');
});
})